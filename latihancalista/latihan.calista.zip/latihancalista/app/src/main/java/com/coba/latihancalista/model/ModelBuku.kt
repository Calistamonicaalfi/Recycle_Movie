package com.coba.latihancalista.model

data class ModelBuku(
    val judul: String,
    val penulis: String

)


